import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Compass, Users, MapPin, Heart, Plane, Camera } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-2xl flex items-center justify-center">
              <Compass className="text-white text-xl" />
            </div>
            <h1 className="text-4xl font-bold text-slate-900">Travelmate</h1>
          </div>
          
          <h2 className="text-5xl font-bold text-slate-900 mb-6 leading-tight">
            Ihre All-in-One
            <br />
            <span className="bg-gradient-to-r from-blue-600 to-emerald-500 bg-clip-text text-transparent">
              Reiseplattform
            </span>
          </h2>
          
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Entdecken Sie einzigartige Reiseziele, planen Sie perfekte Trips mit KI-Unterstützung 
            und vernetzen Sie sich mit Reisenden weltweit. Ihr nächstes Abenteuer beginnt hier.
          </p>
          
          <Button 
            size="lg" 
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg rounded-xl"
            onClick={() => window.location.href = '/api/login'}
          >
            <Plane className="mr-2" />
            Reise beginnen
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Heart className="text-blue-600" />
              </div>
              <CardTitle className="text-lg">Wischen zum Entdecken</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Wischen Sie durch kuratierte Reisen wie Tinder für Reisen. KI lernt Ihre Vorlieben.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <MapPin className="text-emerald-600" />
              </div>
              <CardTitle className="text-lg">KI Reiseplaner</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Erstellen Sie perfekte Reisen mit intelligenter Unterstützung. Von Flügen bis Aktivitäten.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Users className="text-orange-600" />
              </div>
              <CardTitle className="text-lg">Reise-Community</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Vernetzen Sie sich mit gleichgesinnten Reisenden. Teilen Sie Tipps und Erfahrungen.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Camera className="text-purple-600" />
              </div>
              <CardTitle className="text-lg">Share Stories</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">
                Document your journeys and inspire others with your adventures.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-blue-600 to-emerald-500 text-white">
          <CardContent className="p-12 text-center">
            <h3 className="text-3xl font-bold mb-4">Ready to Explore the World?</h3>
            <p className="text-blue-100 mb-6 text-lg">
              Join thousands of travelers who've discovered their perfect trips with Travelmate.
            </p>
            <Button 
              size="lg" 
              variant="secondary"
              className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg rounded-xl"
              onClick={() => window.location.href = '/api/login'}
            >
              Get Started Now
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
