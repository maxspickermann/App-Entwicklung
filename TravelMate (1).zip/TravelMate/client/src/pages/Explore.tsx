import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import TripFilters from "@/components/TripFilters";
import SwipeCard from "@/components/SwipeCard";
import type { Trip } from "@shared/schema";
import Layout from "@/components/Layout";

export default function Explore() {
  const [filters, setFilters] = useState({
    priceRange: [500, 4000] as [number, number],
    duration: "",
    tags: [] as string[],
    destination: "",
  });
  
  const { toast } = useToast();

  // Fetch swipeable trips
  const { 
    data: swipeableTrips = [], 
    isLoading: tripsLoading,
    error: tripsError 
  } = useQuery({
    queryKey: ["/api/trips/swipeable"],
    retry: false,
  });

  const clearFilters = () => {
    setFilters({
      priceRange: [500, 4000],
      duration: "",
      tags: [],
      destination: "",
    });
  };

  // Apply filters to swipeable trips
  const filteredTrips = useMemo(() => {
    if (!Array.isArray(swipeableTrips)) return [];
    
    return swipeableTrips.filter((trip: Trip) => {
      // Price filter
      const price = parseFloat(trip.price);
      if (price < filters.priceRange[0] || price > filters.priceRange[1]) {
        return false;
      }

      // Duration filter
      if (filters.duration) {
        const [min, max] = filters.duration.split('-').map(d => d === '+' ? Infinity : parseInt(d));
        if (trip.duration < min || (max !== Infinity && trip.duration > max)) {
          return false;
        }
      }

      // Destination filter
      if (filters.destination && !trip.country.toLowerCase().includes(filters.destination.toLowerCase())) {
        return false;
      }

      // Tags filter
      if (filters.tags.length > 0) {
        const tripTags = trip.tags || [];
        const hasMatchingTag = filters.tags.some(filterTag => 
          tripTags.some(tripTag => tripTag.toLowerCase().includes(filterTag.toLowerCase()))
        );
        if (!hasMatchingTag) {
          return false;
        }
      }

      return true;
    });
  }, [swipeableTrips, filters]);

  // Handle unauthorized errors
  useEffect(() => {
    if (tripsError && isUnauthorizedError(tripsError)) {
      toast({
        title: "Nicht autorisiert",
        description: "Sie sind abgemeldet. Melde Sie wieder an...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [tripsError, toast]);

  return (
    <Layout activeSection="explore" onSectionChange={() => {}}>
      <div className="min-h-screen bg-gray-50 px-4 py-6 pb-24">
        <div className="max-w-md mx-auto space-y-6">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Reisen entdecken</h1>
            <p className="text-gray-600">Nach rechts wischen für inspirierende Abenteuer</p>
          </div>

          {/* Filters */}
          <div className="flex items-center justify-between mb-4">
            <TripFilters 
              filters={filters}
              onFiltersChange={setFilters}
              onClearFilters={clearFilters}
            />
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Heart className="text-red-500 w-4 h-4" />
              <span className="hidden sm:inline">Wischen zum Liken</span>
            </div>
          </div>
          
          {/* Trip Cards */}
          <div className="relative">
            {tripsLoading ? (
              <Card className="w-full h-96 bg-white shadow-lg">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Lade fantastische Reisen...</p>
                  </div>
                </CardContent>
              </Card>
            ) : filteredTrips.length === 0 ? (
              <Card className="w-full h-96 bg-white shadow-lg">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Heart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {Array.isArray(swipeableTrips) && swipeableTrips.length === 0 ? "Keine weiteren Reisen zu entdecken" : "Keine Reisen entsprechen Ihren Filtern"}
                    </h3>
                    <p className="text-gray-600 mb-4">
                      {Array.isArray(swipeableTrips) && swipeableTrips.length === 0 
                        ? "Sie haben alle verfügbaren Reisen gesehen! Schauen Sie später für neue Abenteuer vorbei."
                        : "Versuchen Sie, Ihre Filter anzupassen, um mehr Reiseoptionen zu sehen."
                      }
                    </p>
                    {Array.isArray(swipeableTrips) && swipeableTrips.length > 0 && (
                      <Button onClick={clearFilters} className="bg-blue-600 hover:bg-blue-700">
                        Filter löschen
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <SwipeCard trips={filteredTrips} />
            )}
          </div>

          {/* Active Filters Display */}
          {(filters.destination || filters.duration || filters.tags.length > 0) && (
            <Card className="mt-4">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    {filters.destination && (
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                        📍 {filters.destination}
                      </span>
                    )}
                    {filters.duration && (
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                        ⏱️ {filters.duration} days
                      </span>
                    )}
                    {filters.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearFilters}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    Alle löschen
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
