# TravelMate - Externe API-Integration-Architektur

## Überblick
Umfassende Architektur für die Integration externer Buchungsservices mit End-to-End-Abwicklung, Stripe-Zahlungen und zentralem Dokumentenmanagement.

## 1. API-Service-Architektur

### 1.1 Flüge - Skyscanner API
**Endpunkt**: RapidAPI Skyscanner
**Kosten**: 1000 kostenlose Anfragen/Monat, dann $0.01/Anfrage
**Features**:
- Live-Flugsuche mit Preisvergleich
- Multi-City-Routen
- Flexible Daten
- Preisalarme

```typescript
// server/services/flightService.ts
interface FlightSearchParams {
  origin: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  adults: number;
  children?: number;
  cabinClass: 'economy' | 'business' | 'first';
}

interface FlightResult {
  id: string;
  price: number;
  airline: string;
  departure: {
    airport: string;
    time: string;
  };
  arrival: {
    airport: string;
    time: string;
  };
  duration: string;
  stops: number;
  bookingUrl: string;
}
```

### 1.2 Hotels - Booking.com API
**Endpunkt**: Booking.com Affiliate Partner API
**Kosten**: Kommissionsbasiert (8-25% je nach Kategorie)
**Features**:
- Hotelsuche mit Bewertungen
- Verfügbarkeits-Check
- Zimmertypen und Preise
- Stornierungsrichtlinien

```typescript
// server/services/hotelService.ts
interface HotelSearchParams {
  destination: string;
  checkIn: string;
  checkOut: string;
  rooms: number;
  adults: number;
  children?: number;
  starRating?: number[];
  priceRange?: { min: number; max: number };
}

interface HotelResult {
  id: string;
  name: string;
  rating: number;
  reviewScore: number;
  price: number;
  currency: string;
  images: string[];
  amenities: string[];
  location: {
    address: string;
    coordinates: { lat: number; lng: number };
  };
  cancellationPolicy: string;
  bookingUrl: string;
}
```

### 1.3 Aktivitäten - GetYourGuide API
**Endpunkt**: GetYourGuide Partner API
**Kosten**: Kommissionsbasiert (8-20%)
**Features**:
- Touren und Aktivitäten
- Tickets für Sehenswürdigkeiten
- Erlebnisse und Ausflüge
- Verfügbarkeiten und Preise

```typescript
// server/services/activityService.ts
interface ActivitySearchParams {
  destination: string;
  category?: string;
  date?: string;
  duration?: string;
  priceRange?: { min: number; max: number };
}

interface ActivityResult {
  id: string;
  title: string;
  description: string;
  price: number;
  duration: string;
  rating: number;
  reviewCount: number;
  images: string[];
  includes: string[];
  meetingPoint: string;
  cancellationPolicy: string;
  bookingUrl: string;
}
```

## 2. In-App-Buchungsarchitektur

### 2.1 Booking-Workflow
```
1. Nutzer wählt Service aus
2. Preisabruf über externe API
3. Buchungsdetails in lokaler DB speichern
4. Stripe-Zahlung initiieren
5. Bei erfolgreicher Zahlung: Buchung über externe API
6. Buchungsbestätigung speichern
7. Dokumente generieren und speichern
```

### 2.2 Database Schema Erweiterung
```sql
-- Buchungen
CREATE TABLE bookings (
  id SERIAL PRIMARY KEY,
  user_id VARCHAR NOT NULL,
  trip_id INTEGER,
  booking_type VARCHAR NOT NULL, -- 'flight', 'hotel', 'activity'
  external_booking_id VARCHAR,
  status VARCHAR NOT NULL, -- 'pending', 'confirmed', 'cancelled'
  total_amount DECIMAL(10,2),
  currency VARCHAR(3),
  booking_data JSONB, -- Alle Buchungsdetails
  payment_intent_id VARCHAR, -- Stripe Payment Intent
  created_at TIMESTAMP DEFAULT NOW(),
  confirmed_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (trip_id) REFERENCES trips(id)
);

-- Dokumente
CREATE TABLE travel_documents (
  id SERIAL PRIMARY KEY,
  booking_id INTEGER NOT NULL,
  document_type VARCHAR NOT NULL, -- 'ticket', 'voucher', 'confirmation', 'invoice'
  file_url VARCHAR,
  file_data JSONB, -- PDF-Daten als Base64
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Zahlungen
CREATE TABLE payments (
  id SERIAL PRIMARY KEY,
  booking_id INTEGER NOT NULL,
  stripe_payment_intent_id VARCHAR NOT NULL,
  amount DECIMAL(10,2),
  currency VARCHAR(3),
  status VARCHAR NOT NULL, -- 'pending', 'succeeded', 'failed'
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);
```

## 3. Stripe-Integration für Zahlungen

### 3.1 Payment-Flow
```typescript
// server/services/paymentService.ts
class PaymentService {
  async createBookingPayment(bookingData: BookingData): Promise<PaymentIntent> {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(bookingData.totalAmount * 100), // Cent
      currency: 'eur',
      metadata: {
        bookingType: bookingData.type,
        userId: bookingData.userId,
        tripId: bookingData.tripId
      }
    });
    
    return paymentIntent;
  }
  
  async confirmBooking(paymentIntentId: string): Promise<void> {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
    
    if (paymentIntent.status === 'succeeded') {
      // Buchung über externe API durchführen
      await this.processExternalBooking(paymentIntent.metadata);
    }
  }
}
```

### 3.2 Webhook-Handling
```typescript
// server/routes/webhooks.ts
app.post('/api/webhooks/stripe', express.raw({type: 'application/json'}), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      await bookingService.confirmBooking(paymentIntent.id);
    }
    
    res.json({received: true});
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(400).send('Webhook error');
  }
});
```

## 4. Dokumentenmanagement

### 4.1 PDF-Generierung
```typescript
// server/services/documentService.ts
class DocumentService {
  async generateTicket(booking: Booking): Promise<Buffer> {
    const pdf = new PDFDocument();
    
    // Ticket-Layout generieren
    pdf.fontSize(20).text('TravelMate Ticket', 50, 50);
    pdf.fontSize(12).text(`Buchung #${booking.id}`, 50, 80);
    
    // QR-Code für Mobile-Zugang
    const qrCode = await QRCode.toDataURL(booking.id.toString());
    pdf.image(qrCode, 450, 50, {width: 100});
    
    return pdf.outputSync();
  }
  
  async storeDocument(bookingId: number, type: string, data: Buffer): Promise<TravelDocument> {
    const document = await storage.createTravelDocument({
      bookingId,
      documentType: type,
      fileData: data.toString('base64')
    });
    
    return document;
  }
}
```

### 4.2 Dokument-Abruf
```typescript
// client/components/BookingDocuments.tsx
function BookingDocuments({ bookingId }: { bookingId: number }) {
  const { data: documents } = useQuery({
    queryKey: [`/api/bookings/${bookingId}/documents`]
  });
  
  const downloadDocument = async (doc: TravelDocument) => {
    const blob = new Blob([Buffer.from(doc.fileData, 'base64')], {
      type: 'application/pdf'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.documentType}_${bookingId}.pdf`;
    a.click();
  };
  
  return (
    <div>
      {documents?.map(doc => (
        <Button key={doc.id} onClick={() => downloadDocument(doc)}>
          {doc.documentType} herunterladen
        </Button>
      ))}
    </div>
  );
}
```

## 5. API-Schlüssel und Konfiguration

### 5.1 Erforderliche Environment Variables
```bash
# Skyscanner API
RAPIDAPI_KEY=your_rapidapi_key
SKYSCANNER_API_URL=https://skyscanner-api.p.rapidapi.com

# Booking.com API
BOOKING_COM_API_KEY=your_booking_com_key
BOOKING_COM_AFFILIATE_ID=your_affiliate_id

# GetYourGuide API
GETYOURGUIDE_API_KEY=your_getyourguide_key
GETYOURGUIDE_PARTNER_ID=your_partner_id

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
VITE_STRIPE_PUBLIC_KEY=pk_test_...
```

### 5.2 Rate Limiting und Caching
```typescript
// server/middleware/rateLimiter.ts
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 Minuten
  max: 100, // Limit pro IP
  message: 'Zu viele API-Anfragen'
});

// server/services/cacheService.ts
class CacheService {
  private cache = new Map();
  
  async get(key: string): Promise<any> {
    return this.cache.get(key);
  }
  
  async set(key: string, value: any, ttl = 300): Promise<void> {
    this.cache.set(key, { value, expires: Date.now() + ttl * 1000 });
  }
}
```

## 6. Frontend-Integration

### 6.1 Booking-Komponenten
```typescript
// client/components/FlightBooking.tsx
function FlightBooking({ searchParams }: { searchParams: FlightSearchParams }) {
  const [selectedFlight, setSelectedFlight] = useState<FlightResult | null>(null);
  const [paymentStep, setPaymentStep] = useState(false);
  
  const { data: flights, isLoading } = useQuery({
    queryKey: ['/api/flights/search', searchParams],
    enabled: !!searchParams.origin
  });
  
  const bookingMutation = useMutation({
    mutationFn: async (flightData: FlightResult) => {
      const response = await apiRequest('POST', '/api/bookings/flight', flightData);
      return response.json();
    },
    onSuccess: (data) => {
      setPaymentStep(true);
    }
  });
  
  return (
    <div>
      {!paymentStep ? (
        <FlightResults 
          flights={flights} 
          onSelect={setSelectedFlight}
          onBook={bookingMutation.mutate}
        />
      ) : (
        <StripePayment bookingId={selectedFlight?.id} />
      )}
    </div>
  );
}
```

### 6.2 Unified Booking Interface
```typescript
// client/pages/BookingHub.tsx
function BookingHub() {
  const [activeTab, setActiveTab] = useState<'flights' | 'hotels' | 'activities'>('flights');
  
  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="flights">Flüge</TabsTrigger>
          <TabsTrigger value="hotels">Hotels</TabsTrigger>
          <TabsTrigger value="activities">Aktivitäten</TabsTrigger>
        </TabsList>
        
        <TabsContent value="flights">
          <FlightBooking />
        </TabsContent>
        
        <TabsContent value="hotels">
          <HotelBooking />
        </TabsContent>
        
        <TabsContent value="activities">
          <ActivityBooking />
        </TabsContent>
      </Tabs>
    </div>
  );
}
```

## 7. Implementierungsschritte

### Phase 1: Backend-Grundlagen (Woche 1-2)
1. Database Schema erweitern
2. Stripe-Integration implementieren
3. API-Service-Klassen erstellen
4. Webhook-Handling einrichten

### Phase 2: API-Integrationen (Woche 3-4)
1. Skyscanner API-Integration
2. Booking.com API-Integration
3. GetYourGuide API-Integration
4. Caching und Rate Limiting

### Phase 3: Frontend-Integration (Woche 5-6)
1. Booking-Komponenten entwickeln
2. Payment-Flow implementieren
3. Dokumenten-Management UI
4. Mobile-Optimierung

### Phase 4: Testing und Optimierung (Woche 7-8)
1. End-to-End-Tests
2. Performance-Optimierung
3. Error-Handling verbessern
4. Dokumentation finalisieren

## 8. Kostenübersicht

### Externe APIs (monatlich)
- Skyscanner: €0 (erste 1000 Anfragen) + €0.01/weitere Anfrage
- Booking.com: 8-25% Kommission pro Buchung
- GetYourGuide: 8-20% Kommission pro Buchung

### Stripe-Gebühren
- 1.4% + €0.25 pro Transaktion (EU-Karten)
- 2.9% + €0.30 pro Transaktion (Nicht-EU-Karten)

### Geschätzter ROI
- Kommissionsbasierte APIs: 20-40% Gewinnmarge
- Transaktionsgebühren: 2-5% der Buchungssumme
- Erwarteter monatlicher Umsatz: €10.000-50.000

## Fazit

Diese Architektur ermöglicht eine vollständige In-App-Buchungserfahrung mit:
- Nahtloser Integration externer APIs
- Sicherer Zahlungsabwicklung
- Zentralem Dokumentenmanagement
- Skalierbarkeit für zukünftige Services

Alle Buchungen werden direkt in der App abgewickelt, ohne externe Weiterleitungen, und bieten eine premium Benutzererfahrung.