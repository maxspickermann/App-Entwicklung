import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Welcome to Travelmate Web</h1>
      <p>This is a basic React Web version for demo purposes.</p>
    </div>
  );
}

export default App;
